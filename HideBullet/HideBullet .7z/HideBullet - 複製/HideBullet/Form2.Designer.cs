﻿namespace HideBullet
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label timeLabel;
            this.pictureBox200 = new System.Windows.Forms.PictureBox();
            this.pictureBox201 = new System.Windows.Forms.PictureBox();
            this.pictureBox202 = new System.Windows.Forms.PictureBox();
            this.pictureBox203 = new System.Windows.Forms.PictureBox();
            this.pictureBox204 = new System.Windows.Forms.PictureBox();
            this.pictureBox205 = new System.Windows.Forms.PictureBox();
            this.pictureBox206 = new System.Windows.Forms.PictureBox();
            this.pictureBox193 = new System.Windows.Forms.PictureBox();
            this.pictureBox194 = new System.Windows.Forms.PictureBox();
            this.pictureBox195 = new System.Windows.Forms.PictureBox();
            this.pictureBox196 = new System.Windows.Forms.PictureBox();
            this.pictureBox197 = new System.Windows.Forms.PictureBox();
            this.pictureBox198 = new System.Windows.Forms.PictureBox();
            this.pictureBox199 = new System.Windows.Forms.PictureBox();
            this.pictureBox186 = new System.Windows.Forms.PictureBox();
            this.pictureBox187 = new System.Windows.Forms.PictureBox();
            this.pictureBox188 = new System.Windows.Forms.PictureBox();
            this.pictureBox189 = new System.Windows.Forms.PictureBox();
            this.pictureBox190 = new System.Windows.Forms.PictureBox();
            this.pictureBox191 = new System.Windows.Forms.PictureBox();
            this.pictureBox192 = new System.Windows.Forms.PictureBox();
            this.pictureBox179 = new System.Windows.Forms.PictureBox();
            this.pictureBox180 = new System.Windows.Forms.PictureBox();
            this.pictureBox181 = new System.Windows.Forms.PictureBox();
            this.pictureBox182 = new System.Windows.Forms.PictureBox();
            this.pictureBox183 = new System.Windows.Forms.PictureBox();
            this.pictureBox184 = new System.Windows.Forms.PictureBox();
            this.pictureBox185 = new System.Windows.Forms.PictureBox();
            this.pictureBox172 = new System.Windows.Forms.PictureBox();
            this.pictureBox173 = new System.Windows.Forms.PictureBox();
            this.pictureBox174 = new System.Windows.Forms.PictureBox();
            this.pictureBox175 = new System.Windows.Forms.PictureBox();
            this.pictureBox176 = new System.Windows.Forms.PictureBox();
            this.pictureBox177 = new System.Windows.Forms.PictureBox();
            this.pictureBox178 = new System.Windows.Forms.PictureBox();
            this.pictureBox165 = new System.Windows.Forms.PictureBox();
            this.pictureBox166 = new System.Windows.Forms.PictureBox();
            this.pictureBox167 = new System.Windows.Forms.PictureBox();
            this.pictureBox168 = new System.Windows.Forms.PictureBox();
            this.pictureBox169 = new System.Windows.Forms.PictureBox();
            this.pictureBox170 = new System.Windows.Forms.PictureBox();
            this.pictureBox171 = new System.Windows.Forms.PictureBox();
            this.pictureBox158 = new System.Windows.Forms.PictureBox();
            this.pictureBox159 = new System.Windows.Forms.PictureBox();
            this.pictureBox160 = new System.Windows.Forms.PictureBox();
            this.pictureBox161 = new System.Windows.Forms.PictureBox();
            this.pictureBox162 = new System.Windows.Forms.PictureBox();
            this.pictureBox163 = new System.Windows.Forms.PictureBox();
            this.pictureBox164 = new System.Windows.Forms.PictureBox();
            this.pictureBox151 = new System.Windows.Forms.PictureBox();
            this.pictureBox152 = new System.Windows.Forms.PictureBox();
            this.pictureBox153 = new System.Windows.Forms.PictureBox();
            this.pictureBox154 = new System.Windows.Forms.PictureBox();
            this.pictureBox155 = new System.Windows.Forms.PictureBox();
            this.pictureBox156 = new System.Windows.Forms.PictureBox();
            this.pictureBox157 = new System.Windows.Forms.PictureBox();
            this.pictureBox144 = new System.Windows.Forms.PictureBox();
            this.pictureBox145 = new System.Windows.Forms.PictureBox();
            this.pictureBox146 = new System.Windows.Forms.PictureBox();
            this.pictureBox147 = new System.Windows.Forms.PictureBox();
            this.pictureBox148 = new System.Windows.Forms.PictureBox();
            this.pictureBox149 = new System.Windows.Forms.PictureBox();
            this.pictureBox150 = new System.Windows.Forms.PictureBox();
            this.pictureBox137 = new System.Windows.Forms.PictureBox();
            this.pictureBox138 = new System.Windows.Forms.PictureBox();
            this.pictureBox139 = new System.Windows.Forms.PictureBox();
            this.pictureBox140 = new System.Windows.Forms.PictureBox();
            this.pictureBox141 = new System.Windows.Forms.PictureBox();
            this.pictureBox142 = new System.Windows.Forms.PictureBox();
            this.pictureBox143 = new System.Windows.Forms.PictureBox();
            this.pictureBox130 = new System.Windows.Forms.PictureBox();
            this.pictureBox131 = new System.Windows.Forms.PictureBox();
            this.pictureBox132 = new System.Windows.Forms.PictureBox();
            this.pictureBox133 = new System.Windows.Forms.PictureBox();
            this.pictureBox134 = new System.Windows.Forms.PictureBox();
            this.pictureBox135 = new System.Windows.Forms.PictureBox();
            this.pictureBox136 = new System.Windows.Forms.PictureBox();
            this.pictureBox123 = new System.Windows.Forms.PictureBox();
            this.pictureBox124 = new System.Windows.Forms.PictureBox();
            this.pictureBox125 = new System.Windows.Forms.PictureBox();
            this.pictureBox126 = new System.Windows.Forms.PictureBox();
            this.pictureBox127 = new System.Windows.Forms.PictureBox();
            this.pictureBox128 = new System.Windows.Forms.PictureBox();
            this.pictureBox129 = new System.Windows.Forms.PictureBox();
            this.pictureBox116 = new System.Windows.Forms.PictureBox();
            this.pictureBox117 = new System.Windows.Forms.PictureBox();
            this.pictureBox118 = new System.Windows.Forms.PictureBox();
            this.pictureBox119 = new System.Windows.Forms.PictureBox();
            this.pictureBox120 = new System.Windows.Forms.PictureBox();
            this.pictureBox121 = new System.Windows.Forms.PictureBox();
            this.pictureBox122 = new System.Windows.Forms.PictureBox();
            this.pictureBox109 = new System.Windows.Forms.PictureBox();
            this.pictureBox110 = new System.Windows.Forms.PictureBox();
            this.pictureBox111 = new System.Windows.Forms.PictureBox();
            this.pictureBox112 = new System.Windows.Forms.PictureBox();
            this.pictureBox113 = new System.Windows.Forms.PictureBox();
            this.pictureBox114 = new System.Windows.Forms.PictureBox();
            this.pictureBox115 = new System.Windows.Forms.PictureBox();
            this.pictureBox108 = new System.Windows.Forms.PictureBox();
            this.pictureBox107 = new System.Windows.Forms.PictureBox();
            this.pictureBox106 = new System.Windows.Forms.PictureBox();
            this.pictureBox105 = new System.Windows.Forms.PictureBox();
            this.pictureBox104 = new System.Windows.Forms.PictureBox();
            this.pictureBox103 = new System.Windows.Forms.PictureBox();
            this.pictureBox102 = new System.Windows.Forms.PictureBox();
            this.pictureBox101 = new System.Windows.Forms.PictureBox();
            this.pictureBox100 = new System.Windows.Forms.PictureBox();
            this.pictureBox89 = new System.Windows.Forms.PictureBox();
            this.pictureBox90 = new System.Windows.Forms.PictureBox();
            this.pictureBox91 = new System.Windows.Forms.PictureBox();
            this.pictureBox92 = new System.Windows.Forms.PictureBox();
            this.pictureBox93 = new System.Windows.Forms.PictureBox();
            this.pictureBox94 = new System.Windows.Forms.PictureBox();
            this.pictureBox95 = new System.Windows.Forms.PictureBox();
            this.pictureBox96 = new System.Windows.Forms.PictureBox();
            this.pictureBox97 = new System.Windows.Forms.PictureBox();
            this.pictureBox98 = new System.Windows.Forms.PictureBox();
            this.pictureBox99 = new System.Windows.Forms.PictureBox();
            this.pictureBox78 = new System.Windows.Forms.PictureBox();
            this.pictureBox79 = new System.Windows.Forms.PictureBox();
            this.pictureBox80 = new System.Windows.Forms.PictureBox();
            this.pictureBox81 = new System.Windows.Forms.PictureBox();
            this.pictureBox82 = new System.Windows.Forms.PictureBox();
            this.pictureBox83 = new System.Windows.Forms.PictureBox();
            this.pictureBox84 = new System.Windows.Forms.PictureBox();
            this.pictureBox85 = new System.Windows.Forms.PictureBox();
            this.pictureBox86 = new System.Windows.Forms.PictureBox();
            this.pictureBox87 = new System.Windows.Forms.PictureBox();
            this.pictureBox88 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox68 = new System.Windows.Forms.PictureBox();
            this.pictureBox69 = new System.Windows.Forms.PictureBox();
            this.pictureBox70 = new System.Windows.Forms.PictureBox();
            this.pictureBox71 = new System.Windows.Forms.PictureBox();
            this.pictureBox72 = new System.Windows.Forms.PictureBox();
            this.pictureBox73 = new System.Windows.Forms.PictureBox();
            this.pictureBox74 = new System.Windows.Forms.PictureBox();
            this.pictureBox75 = new System.Windows.Forms.PictureBox();
            this.pictureBox76 = new System.Windows.Forms.PictureBox();
            this.pictureBox77 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.Player = new System.Windows.Forms.PictureBox();
            this.Bsecond = new System.Windows.Forms.Timer(this.components);
            this.Slow = new System.Windows.Forms.Timer(this.components);
            this.Normal = new System.Windows.Forms.Timer(this.components);
            this.Second = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Trace = new System.Windows.Forms.Timer(this.components);
            this.Randd = new System.Windows.Forms.Timer(this.components);
            this.Fast = new System.Windows.Forms.Timer(this.components);
            this.BackG = new System.Windows.Forms.Timer(this.components);
            this.Nice = new System.Windows.Forms.Timer(this.components);
            this.Boom = new System.Windows.Forms.Timer(this.components);
            this.Remix = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.database1DataSet = new HideBullet.Database1DataSet();
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter = new HideBullet.Database1DataSetTableAdapters.TableTableAdapter();
            this.tableAdapterManager = new HideBullet.Database1DataSetTableAdapters.TableAdapterManager();
            this.tableDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.nameTextBox1 = new System.Windows.Forms.TextBox();
            this.timeTextBox1 = new System.Windows.Forms.TextBox();
            nameLabel = new System.Windows.Forms.Label();
            timeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox200)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox201)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox202)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox203)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox204)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox205)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox206)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox193)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox194)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox195)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox196)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox197)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox198)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox199)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox186)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox187)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox188)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox189)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox190)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox191)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox192)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox179)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox180)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox181)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox182)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox183)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox184)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox185)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox172)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox173)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox174)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox175)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox176)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox177)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox178)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox165)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox166)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox167)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox168)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox169)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox170)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox171)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox158)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox159)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox160)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox161)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox162)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox163)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox164)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox151)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox152)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox156)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox157)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox144)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox145)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox146)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox147)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox149)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox150)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox140)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox141)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox142)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox143)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox130)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox132)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox133)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox136)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox125)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox126)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox127)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox128)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox129)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Font = new System.Drawing.Font("jf open 粉圓 1.1", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            nameLabel.Location = new System.Drawing.Point(14, 34);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(47, 17);
            nameLabel.TabIndex = 534;
            nameLabel.Text = "Name:";
            nameLabel.Visible = false;
            // 
            // timeLabel
            // 
            timeLabel.AutoSize = true;
            timeLabel.Font = new System.Drawing.Font("jf open 粉圓 1.1", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            timeLabel.Location = new System.Drawing.Point(18, 62);
            timeLabel.Name = "timeLabel";
            timeLabel.Size = new System.Drawing.Size(41, 17);
            timeLabel.TabIndex = 536;
            timeLabel.Text = "Time:";
            timeLabel.Visible = false;
            // 
            // pictureBox200
            // 
            this.pictureBox200.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox200.Location = new System.Drawing.Point(209, 220);
            this.pictureBox200.Name = "pictureBox200";
            this.pictureBox200.Size = new System.Drawing.Size(1, 2);
            this.pictureBox200.TabIndex = 530;
            this.pictureBox200.TabStop = false;
            // 
            // pictureBox201
            // 
            this.pictureBox201.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox201.Location = new System.Drawing.Point(201, 212);
            this.pictureBox201.Name = "pictureBox201";
            this.pictureBox201.Size = new System.Drawing.Size(1, 2);
            this.pictureBox201.TabIndex = 529;
            this.pictureBox201.TabStop = false;
            // 
            // pictureBox202
            // 
            this.pictureBox202.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox202.Location = new System.Drawing.Point(193, 204);
            this.pictureBox202.Name = "pictureBox202";
            this.pictureBox202.Size = new System.Drawing.Size(1, 2);
            this.pictureBox202.TabIndex = 528;
            this.pictureBox202.TabStop = false;
            // 
            // pictureBox203
            // 
            this.pictureBox203.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox203.Location = new System.Drawing.Point(185, 196);
            this.pictureBox203.Name = "pictureBox203";
            this.pictureBox203.Size = new System.Drawing.Size(1, 2);
            this.pictureBox203.TabIndex = 527;
            this.pictureBox203.TabStop = false;
            // 
            // pictureBox204
            // 
            this.pictureBox204.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox204.Location = new System.Drawing.Point(177, 188);
            this.pictureBox204.Name = "pictureBox204";
            this.pictureBox204.Size = new System.Drawing.Size(1, 2);
            this.pictureBox204.TabIndex = 526;
            this.pictureBox204.TabStop = false;
            // 
            // pictureBox205
            // 
            this.pictureBox205.BackColor = System.Drawing.Color.Blue;
            this.pictureBox205.Location = new System.Drawing.Point(169, 180);
            this.pictureBox205.Name = "pictureBox205";
            this.pictureBox205.Size = new System.Drawing.Size(1, 2);
            this.pictureBox205.TabIndex = 525;
            this.pictureBox205.TabStop = false;
            // 
            // pictureBox206
            // 
            this.pictureBox206.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox206.Location = new System.Drawing.Point(161, 172);
            this.pictureBox206.Name = "pictureBox206";
            this.pictureBox206.Size = new System.Drawing.Size(1, 2);
            this.pictureBox206.TabIndex = 524;
            this.pictureBox206.TabStop = false;
            // 
            // pictureBox193
            // 
            this.pictureBox193.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox193.Location = new System.Drawing.Point(201, 212);
            this.pictureBox193.Name = "pictureBox193";
            this.pictureBox193.Size = new System.Drawing.Size(1, 2);
            this.pictureBox193.TabIndex = 523;
            this.pictureBox193.TabStop = false;
            // 
            // pictureBox194
            // 
            this.pictureBox194.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox194.Location = new System.Drawing.Point(193, 204);
            this.pictureBox194.Name = "pictureBox194";
            this.pictureBox194.Size = new System.Drawing.Size(1, 2);
            this.pictureBox194.TabIndex = 522;
            this.pictureBox194.TabStop = false;
            // 
            // pictureBox195
            // 
            this.pictureBox195.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox195.Location = new System.Drawing.Point(185, 196);
            this.pictureBox195.Name = "pictureBox195";
            this.pictureBox195.Size = new System.Drawing.Size(1, 2);
            this.pictureBox195.TabIndex = 521;
            this.pictureBox195.TabStop = false;
            // 
            // pictureBox196
            // 
            this.pictureBox196.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox196.Location = new System.Drawing.Point(177, 188);
            this.pictureBox196.Name = "pictureBox196";
            this.pictureBox196.Size = new System.Drawing.Size(1, 2);
            this.pictureBox196.TabIndex = 520;
            this.pictureBox196.TabStop = false;
            // 
            // pictureBox197
            // 
            this.pictureBox197.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox197.Location = new System.Drawing.Point(169, 180);
            this.pictureBox197.Name = "pictureBox197";
            this.pictureBox197.Size = new System.Drawing.Size(1, 2);
            this.pictureBox197.TabIndex = 519;
            this.pictureBox197.TabStop = false;
            // 
            // pictureBox198
            // 
            this.pictureBox198.BackColor = System.Drawing.Color.Blue;
            this.pictureBox198.Location = new System.Drawing.Point(161, 172);
            this.pictureBox198.Name = "pictureBox198";
            this.pictureBox198.Size = new System.Drawing.Size(1, 2);
            this.pictureBox198.TabIndex = 518;
            this.pictureBox198.TabStop = false;
            // 
            // pictureBox199
            // 
            this.pictureBox199.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox199.Location = new System.Drawing.Point(153, 164);
            this.pictureBox199.Name = "pictureBox199";
            this.pictureBox199.Size = new System.Drawing.Size(1, 2);
            this.pictureBox199.TabIndex = 517;
            this.pictureBox199.TabStop = false;
            // 
            // pictureBox186
            // 
            this.pictureBox186.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox186.Location = new System.Drawing.Point(193, 204);
            this.pictureBox186.Name = "pictureBox186";
            this.pictureBox186.Size = new System.Drawing.Size(1, 2);
            this.pictureBox186.TabIndex = 516;
            this.pictureBox186.TabStop = false;
            // 
            // pictureBox187
            // 
            this.pictureBox187.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox187.Location = new System.Drawing.Point(185, 196);
            this.pictureBox187.Name = "pictureBox187";
            this.pictureBox187.Size = new System.Drawing.Size(1, 2);
            this.pictureBox187.TabIndex = 515;
            this.pictureBox187.TabStop = false;
            // 
            // pictureBox188
            // 
            this.pictureBox188.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox188.Location = new System.Drawing.Point(177, 188);
            this.pictureBox188.Name = "pictureBox188";
            this.pictureBox188.Size = new System.Drawing.Size(1, 2);
            this.pictureBox188.TabIndex = 514;
            this.pictureBox188.TabStop = false;
            // 
            // pictureBox189
            // 
            this.pictureBox189.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox189.Location = new System.Drawing.Point(169, 180);
            this.pictureBox189.Name = "pictureBox189";
            this.pictureBox189.Size = new System.Drawing.Size(1, 2);
            this.pictureBox189.TabIndex = 513;
            this.pictureBox189.TabStop = false;
            // 
            // pictureBox190
            // 
            this.pictureBox190.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox190.Location = new System.Drawing.Point(161, 172);
            this.pictureBox190.Name = "pictureBox190";
            this.pictureBox190.Size = new System.Drawing.Size(1, 2);
            this.pictureBox190.TabIndex = 512;
            this.pictureBox190.TabStop = false;
            // 
            // pictureBox191
            // 
            this.pictureBox191.BackColor = System.Drawing.Color.Blue;
            this.pictureBox191.Location = new System.Drawing.Point(153, 164);
            this.pictureBox191.Name = "pictureBox191";
            this.pictureBox191.Size = new System.Drawing.Size(1, 2);
            this.pictureBox191.TabIndex = 511;
            this.pictureBox191.TabStop = false;
            // 
            // pictureBox192
            // 
            this.pictureBox192.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox192.Location = new System.Drawing.Point(145, 156);
            this.pictureBox192.Name = "pictureBox192";
            this.pictureBox192.Size = new System.Drawing.Size(1, 2);
            this.pictureBox192.TabIndex = 510;
            this.pictureBox192.TabStop = false;
            // 
            // pictureBox179
            // 
            this.pictureBox179.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox179.Location = new System.Drawing.Point(185, 196);
            this.pictureBox179.Name = "pictureBox179";
            this.pictureBox179.Size = new System.Drawing.Size(1, 2);
            this.pictureBox179.TabIndex = 509;
            this.pictureBox179.TabStop = false;
            // 
            // pictureBox180
            // 
            this.pictureBox180.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox180.Location = new System.Drawing.Point(177, 188);
            this.pictureBox180.Name = "pictureBox180";
            this.pictureBox180.Size = new System.Drawing.Size(1, 2);
            this.pictureBox180.TabIndex = 508;
            this.pictureBox180.TabStop = false;
            // 
            // pictureBox181
            // 
            this.pictureBox181.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox181.Location = new System.Drawing.Point(169, 180);
            this.pictureBox181.Name = "pictureBox181";
            this.pictureBox181.Size = new System.Drawing.Size(1, 2);
            this.pictureBox181.TabIndex = 507;
            this.pictureBox181.TabStop = false;
            // 
            // pictureBox182
            // 
            this.pictureBox182.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox182.Location = new System.Drawing.Point(161, 172);
            this.pictureBox182.Name = "pictureBox182";
            this.pictureBox182.Size = new System.Drawing.Size(1, 2);
            this.pictureBox182.TabIndex = 506;
            this.pictureBox182.TabStop = false;
            // 
            // pictureBox183
            // 
            this.pictureBox183.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox183.Location = new System.Drawing.Point(153, 164);
            this.pictureBox183.Name = "pictureBox183";
            this.pictureBox183.Size = new System.Drawing.Size(1, 2);
            this.pictureBox183.TabIndex = 505;
            this.pictureBox183.TabStop = false;
            // 
            // pictureBox184
            // 
            this.pictureBox184.BackColor = System.Drawing.Color.Blue;
            this.pictureBox184.Location = new System.Drawing.Point(145, 156);
            this.pictureBox184.Name = "pictureBox184";
            this.pictureBox184.Size = new System.Drawing.Size(1, 2);
            this.pictureBox184.TabIndex = 504;
            this.pictureBox184.TabStop = false;
            // 
            // pictureBox185
            // 
            this.pictureBox185.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox185.Location = new System.Drawing.Point(137, 148);
            this.pictureBox185.Name = "pictureBox185";
            this.pictureBox185.Size = new System.Drawing.Size(1, 2);
            this.pictureBox185.TabIndex = 503;
            this.pictureBox185.TabStop = false;
            // 
            // pictureBox172
            // 
            this.pictureBox172.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox172.Location = new System.Drawing.Point(177, 188);
            this.pictureBox172.Name = "pictureBox172";
            this.pictureBox172.Size = new System.Drawing.Size(1, 2);
            this.pictureBox172.TabIndex = 502;
            this.pictureBox172.TabStop = false;
            // 
            // pictureBox173
            // 
            this.pictureBox173.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox173.Location = new System.Drawing.Point(169, 180);
            this.pictureBox173.Name = "pictureBox173";
            this.pictureBox173.Size = new System.Drawing.Size(1, 2);
            this.pictureBox173.TabIndex = 501;
            this.pictureBox173.TabStop = false;
            // 
            // pictureBox174
            // 
            this.pictureBox174.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox174.Location = new System.Drawing.Point(161, 172);
            this.pictureBox174.Name = "pictureBox174";
            this.pictureBox174.Size = new System.Drawing.Size(1, 2);
            this.pictureBox174.TabIndex = 500;
            this.pictureBox174.TabStop = false;
            // 
            // pictureBox175
            // 
            this.pictureBox175.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox175.Location = new System.Drawing.Point(153, 164);
            this.pictureBox175.Name = "pictureBox175";
            this.pictureBox175.Size = new System.Drawing.Size(1, 2);
            this.pictureBox175.TabIndex = 499;
            this.pictureBox175.TabStop = false;
            // 
            // pictureBox176
            // 
            this.pictureBox176.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox176.Location = new System.Drawing.Point(145, 156);
            this.pictureBox176.Name = "pictureBox176";
            this.pictureBox176.Size = new System.Drawing.Size(1, 2);
            this.pictureBox176.TabIndex = 498;
            this.pictureBox176.TabStop = false;
            // 
            // pictureBox177
            // 
            this.pictureBox177.BackColor = System.Drawing.Color.Blue;
            this.pictureBox177.Location = new System.Drawing.Point(137, 148);
            this.pictureBox177.Name = "pictureBox177";
            this.pictureBox177.Size = new System.Drawing.Size(1, 2);
            this.pictureBox177.TabIndex = 497;
            this.pictureBox177.TabStop = false;
            // 
            // pictureBox178
            // 
            this.pictureBox178.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox178.Location = new System.Drawing.Point(129, 140);
            this.pictureBox178.Name = "pictureBox178";
            this.pictureBox178.Size = new System.Drawing.Size(1, 2);
            this.pictureBox178.TabIndex = 496;
            this.pictureBox178.TabStop = false;
            // 
            // pictureBox165
            // 
            this.pictureBox165.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox165.Location = new System.Drawing.Point(169, 180);
            this.pictureBox165.Name = "pictureBox165";
            this.pictureBox165.Size = new System.Drawing.Size(1, 2);
            this.pictureBox165.TabIndex = 495;
            this.pictureBox165.TabStop = false;
            // 
            // pictureBox166
            // 
            this.pictureBox166.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox166.Location = new System.Drawing.Point(161, 172);
            this.pictureBox166.Name = "pictureBox166";
            this.pictureBox166.Size = new System.Drawing.Size(1, 2);
            this.pictureBox166.TabIndex = 494;
            this.pictureBox166.TabStop = false;
            // 
            // pictureBox167
            // 
            this.pictureBox167.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox167.Location = new System.Drawing.Point(153, 164);
            this.pictureBox167.Name = "pictureBox167";
            this.pictureBox167.Size = new System.Drawing.Size(1, 2);
            this.pictureBox167.TabIndex = 493;
            this.pictureBox167.TabStop = false;
            // 
            // pictureBox168
            // 
            this.pictureBox168.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox168.Location = new System.Drawing.Point(145, 156);
            this.pictureBox168.Name = "pictureBox168";
            this.pictureBox168.Size = new System.Drawing.Size(1, 2);
            this.pictureBox168.TabIndex = 492;
            this.pictureBox168.TabStop = false;
            // 
            // pictureBox169
            // 
            this.pictureBox169.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox169.Location = new System.Drawing.Point(137, 148);
            this.pictureBox169.Name = "pictureBox169";
            this.pictureBox169.Size = new System.Drawing.Size(1, 2);
            this.pictureBox169.TabIndex = 491;
            this.pictureBox169.TabStop = false;
            // 
            // pictureBox170
            // 
            this.pictureBox170.BackColor = System.Drawing.Color.Blue;
            this.pictureBox170.Location = new System.Drawing.Point(129, 140);
            this.pictureBox170.Name = "pictureBox170";
            this.pictureBox170.Size = new System.Drawing.Size(1, 2);
            this.pictureBox170.TabIndex = 490;
            this.pictureBox170.TabStop = false;
            // 
            // pictureBox171
            // 
            this.pictureBox171.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox171.Location = new System.Drawing.Point(121, 132);
            this.pictureBox171.Name = "pictureBox171";
            this.pictureBox171.Size = new System.Drawing.Size(1, 2);
            this.pictureBox171.TabIndex = 489;
            this.pictureBox171.TabStop = false;
            // 
            // pictureBox158
            // 
            this.pictureBox158.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox158.Location = new System.Drawing.Point(161, 172);
            this.pictureBox158.Name = "pictureBox158";
            this.pictureBox158.Size = new System.Drawing.Size(1, 2);
            this.pictureBox158.TabIndex = 488;
            this.pictureBox158.TabStop = false;
            // 
            // pictureBox159
            // 
            this.pictureBox159.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox159.Location = new System.Drawing.Point(153, 164);
            this.pictureBox159.Name = "pictureBox159";
            this.pictureBox159.Size = new System.Drawing.Size(1, 2);
            this.pictureBox159.TabIndex = 487;
            this.pictureBox159.TabStop = false;
            // 
            // pictureBox160
            // 
            this.pictureBox160.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox160.Location = new System.Drawing.Point(145, 156);
            this.pictureBox160.Name = "pictureBox160";
            this.pictureBox160.Size = new System.Drawing.Size(1, 2);
            this.pictureBox160.TabIndex = 486;
            this.pictureBox160.TabStop = false;
            // 
            // pictureBox161
            // 
            this.pictureBox161.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox161.Location = new System.Drawing.Point(137, 148);
            this.pictureBox161.Name = "pictureBox161";
            this.pictureBox161.Size = new System.Drawing.Size(1, 2);
            this.pictureBox161.TabIndex = 485;
            this.pictureBox161.TabStop = false;
            // 
            // pictureBox162
            // 
            this.pictureBox162.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox162.Location = new System.Drawing.Point(129, 140);
            this.pictureBox162.Name = "pictureBox162";
            this.pictureBox162.Size = new System.Drawing.Size(1, 2);
            this.pictureBox162.TabIndex = 484;
            this.pictureBox162.TabStop = false;
            // 
            // pictureBox163
            // 
            this.pictureBox163.BackColor = System.Drawing.Color.Blue;
            this.pictureBox163.Location = new System.Drawing.Point(121, 132);
            this.pictureBox163.Name = "pictureBox163";
            this.pictureBox163.Size = new System.Drawing.Size(1, 2);
            this.pictureBox163.TabIndex = 483;
            this.pictureBox163.TabStop = false;
            // 
            // pictureBox164
            // 
            this.pictureBox164.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox164.Location = new System.Drawing.Point(113, 124);
            this.pictureBox164.Name = "pictureBox164";
            this.pictureBox164.Size = new System.Drawing.Size(1, 2);
            this.pictureBox164.TabIndex = 482;
            this.pictureBox164.TabStop = false;
            // 
            // pictureBox151
            // 
            this.pictureBox151.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox151.Location = new System.Drawing.Point(153, 164);
            this.pictureBox151.Name = "pictureBox151";
            this.pictureBox151.Size = new System.Drawing.Size(1, 2);
            this.pictureBox151.TabIndex = 481;
            this.pictureBox151.TabStop = false;
            // 
            // pictureBox152
            // 
            this.pictureBox152.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox152.Location = new System.Drawing.Point(145, 156);
            this.pictureBox152.Name = "pictureBox152";
            this.pictureBox152.Size = new System.Drawing.Size(1, 2);
            this.pictureBox152.TabIndex = 480;
            this.pictureBox152.TabStop = false;
            // 
            // pictureBox153
            // 
            this.pictureBox153.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox153.Location = new System.Drawing.Point(137, 148);
            this.pictureBox153.Name = "pictureBox153";
            this.pictureBox153.Size = new System.Drawing.Size(1, 2);
            this.pictureBox153.TabIndex = 479;
            this.pictureBox153.TabStop = false;
            // 
            // pictureBox154
            // 
            this.pictureBox154.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox154.Location = new System.Drawing.Point(129, 140);
            this.pictureBox154.Name = "pictureBox154";
            this.pictureBox154.Size = new System.Drawing.Size(1, 2);
            this.pictureBox154.TabIndex = 478;
            this.pictureBox154.TabStop = false;
            // 
            // pictureBox155
            // 
            this.pictureBox155.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox155.Location = new System.Drawing.Point(121, 132);
            this.pictureBox155.Name = "pictureBox155";
            this.pictureBox155.Size = new System.Drawing.Size(1, 2);
            this.pictureBox155.TabIndex = 477;
            this.pictureBox155.TabStop = false;
            // 
            // pictureBox156
            // 
            this.pictureBox156.BackColor = System.Drawing.Color.Blue;
            this.pictureBox156.Location = new System.Drawing.Point(113, 124);
            this.pictureBox156.Name = "pictureBox156";
            this.pictureBox156.Size = new System.Drawing.Size(1, 2);
            this.pictureBox156.TabIndex = 476;
            this.pictureBox156.TabStop = false;
            // 
            // pictureBox157
            // 
            this.pictureBox157.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox157.Location = new System.Drawing.Point(105, 116);
            this.pictureBox157.Name = "pictureBox157";
            this.pictureBox157.Size = new System.Drawing.Size(1, 2);
            this.pictureBox157.TabIndex = 475;
            this.pictureBox157.TabStop = false;
            // 
            // pictureBox144
            // 
            this.pictureBox144.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox144.Location = new System.Drawing.Point(145, 156);
            this.pictureBox144.Name = "pictureBox144";
            this.pictureBox144.Size = new System.Drawing.Size(1, 2);
            this.pictureBox144.TabIndex = 474;
            this.pictureBox144.TabStop = false;
            // 
            // pictureBox145
            // 
            this.pictureBox145.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox145.Location = new System.Drawing.Point(137, 148);
            this.pictureBox145.Name = "pictureBox145";
            this.pictureBox145.Size = new System.Drawing.Size(1, 2);
            this.pictureBox145.TabIndex = 473;
            this.pictureBox145.TabStop = false;
            // 
            // pictureBox146
            // 
            this.pictureBox146.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox146.Location = new System.Drawing.Point(129, 140);
            this.pictureBox146.Name = "pictureBox146";
            this.pictureBox146.Size = new System.Drawing.Size(1, 2);
            this.pictureBox146.TabIndex = 472;
            this.pictureBox146.TabStop = false;
            // 
            // pictureBox147
            // 
            this.pictureBox147.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox147.Location = new System.Drawing.Point(121, 132);
            this.pictureBox147.Name = "pictureBox147";
            this.pictureBox147.Size = new System.Drawing.Size(1, 2);
            this.pictureBox147.TabIndex = 471;
            this.pictureBox147.TabStop = false;
            // 
            // pictureBox148
            // 
            this.pictureBox148.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox148.Location = new System.Drawing.Point(113, 124);
            this.pictureBox148.Name = "pictureBox148";
            this.pictureBox148.Size = new System.Drawing.Size(1, 2);
            this.pictureBox148.TabIndex = 470;
            this.pictureBox148.TabStop = false;
            // 
            // pictureBox149
            // 
            this.pictureBox149.BackColor = System.Drawing.Color.Blue;
            this.pictureBox149.Location = new System.Drawing.Point(105, 116);
            this.pictureBox149.Name = "pictureBox149";
            this.pictureBox149.Size = new System.Drawing.Size(1, 2);
            this.pictureBox149.TabIndex = 469;
            this.pictureBox149.TabStop = false;
            // 
            // pictureBox150
            // 
            this.pictureBox150.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox150.Location = new System.Drawing.Point(97, 108);
            this.pictureBox150.Name = "pictureBox150";
            this.pictureBox150.Size = new System.Drawing.Size(1, 2);
            this.pictureBox150.TabIndex = 468;
            this.pictureBox150.TabStop = false;
            // 
            // pictureBox137
            // 
            this.pictureBox137.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox137.Location = new System.Drawing.Point(137, 148);
            this.pictureBox137.Name = "pictureBox137";
            this.pictureBox137.Size = new System.Drawing.Size(1, 2);
            this.pictureBox137.TabIndex = 467;
            this.pictureBox137.TabStop = false;
            // 
            // pictureBox138
            // 
            this.pictureBox138.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox138.Location = new System.Drawing.Point(129, 140);
            this.pictureBox138.Name = "pictureBox138";
            this.pictureBox138.Size = new System.Drawing.Size(1, 2);
            this.pictureBox138.TabIndex = 466;
            this.pictureBox138.TabStop = false;
            // 
            // pictureBox139
            // 
            this.pictureBox139.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox139.Location = new System.Drawing.Point(121, 132);
            this.pictureBox139.Name = "pictureBox139";
            this.pictureBox139.Size = new System.Drawing.Size(1, 2);
            this.pictureBox139.TabIndex = 465;
            this.pictureBox139.TabStop = false;
            // 
            // pictureBox140
            // 
            this.pictureBox140.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox140.Location = new System.Drawing.Point(113, 124);
            this.pictureBox140.Name = "pictureBox140";
            this.pictureBox140.Size = new System.Drawing.Size(1, 2);
            this.pictureBox140.TabIndex = 464;
            this.pictureBox140.TabStop = false;
            // 
            // pictureBox141
            // 
            this.pictureBox141.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox141.Location = new System.Drawing.Point(105, 116);
            this.pictureBox141.Name = "pictureBox141";
            this.pictureBox141.Size = new System.Drawing.Size(1, 2);
            this.pictureBox141.TabIndex = 463;
            this.pictureBox141.TabStop = false;
            // 
            // pictureBox142
            // 
            this.pictureBox142.BackColor = System.Drawing.Color.Blue;
            this.pictureBox142.Location = new System.Drawing.Point(97, 108);
            this.pictureBox142.Name = "pictureBox142";
            this.pictureBox142.Size = new System.Drawing.Size(1, 2);
            this.pictureBox142.TabIndex = 462;
            this.pictureBox142.TabStop = false;
            // 
            // pictureBox143
            // 
            this.pictureBox143.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox143.Location = new System.Drawing.Point(89, 100);
            this.pictureBox143.Name = "pictureBox143";
            this.pictureBox143.Size = new System.Drawing.Size(1, 2);
            this.pictureBox143.TabIndex = 461;
            this.pictureBox143.TabStop = false;
            // 
            // pictureBox130
            // 
            this.pictureBox130.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox130.Location = new System.Drawing.Point(129, 140);
            this.pictureBox130.Name = "pictureBox130";
            this.pictureBox130.Size = new System.Drawing.Size(1, 2);
            this.pictureBox130.TabIndex = 460;
            this.pictureBox130.TabStop = false;
            // 
            // pictureBox131
            // 
            this.pictureBox131.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox131.Location = new System.Drawing.Point(121, 132);
            this.pictureBox131.Name = "pictureBox131";
            this.pictureBox131.Size = new System.Drawing.Size(1, 2);
            this.pictureBox131.TabIndex = 459;
            this.pictureBox131.TabStop = false;
            // 
            // pictureBox132
            // 
            this.pictureBox132.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox132.Location = new System.Drawing.Point(113, 124);
            this.pictureBox132.Name = "pictureBox132";
            this.pictureBox132.Size = new System.Drawing.Size(1, 2);
            this.pictureBox132.TabIndex = 458;
            this.pictureBox132.TabStop = false;
            // 
            // pictureBox133
            // 
            this.pictureBox133.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox133.Location = new System.Drawing.Point(105, 116);
            this.pictureBox133.Name = "pictureBox133";
            this.pictureBox133.Size = new System.Drawing.Size(1, 2);
            this.pictureBox133.TabIndex = 457;
            this.pictureBox133.TabStop = false;
            // 
            // pictureBox134
            // 
            this.pictureBox134.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox134.Location = new System.Drawing.Point(97, 108);
            this.pictureBox134.Name = "pictureBox134";
            this.pictureBox134.Size = new System.Drawing.Size(1, 2);
            this.pictureBox134.TabIndex = 456;
            this.pictureBox134.TabStop = false;
            // 
            // pictureBox135
            // 
            this.pictureBox135.BackColor = System.Drawing.Color.Blue;
            this.pictureBox135.Location = new System.Drawing.Point(89, 100);
            this.pictureBox135.Name = "pictureBox135";
            this.pictureBox135.Size = new System.Drawing.Size(1, 2);
            this.pictureBox135.TabIndex = 455;
            this.pictureBox135.TabStop = false;
            // 
            // pictureBox136
            // 
            this.pictureBox136.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox136.Location = new System.Drawing.Point(81, 92);
            this.pictureBox136.Name = "pictureBox136";
            this.pictureBox136.Size = new System.Drawing.Size(1, 2);
            this.pictureBox136.TabIndex = 454;
            this.pictureBox136.TabStop = false;
            // 
            // pictureBox123
            // 
            this.pictureBox123.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox123.Location = new System.Drawing.Point(121, 132);
            this.pictureBox123.Name = "pictureBox123";
            this.pictureBox123.Size = new System.Drawing.Size(1, 2);
            this.pictureBox123.TabIndex = 453;
            this.pictureBox123.TabStop = false;
            // 
            // pictureBox124
            // 
            this.pictureBox124.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox124.Location = new System.Drawing.Point(113, 124);
            this.pictureBox124.Name = "pictureBox124";
            this.pictureBox124.Size = new System.Drawing.Size(1, 2);
            this.pictureBox124.TabIndex = 452;
            this.pictureBox124.TabStop = false;
            // 
            // pictureBox125
            // 
            this.pictureBox125.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox125.Location = new System.Drawing.Point(105, 116);
            this.pictureBox125.Name = "pictureBox125";
            this.pictureBox125.Size = new System.Drawing.Size(1, 2);
            this.pictureBox125.TabIndex = 451;
            this.pictureBox125.TabStop = false;
            // 
            // pictureBox126
            // 
            this.pictureBox126.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox126.Location = new System.Drawing.Point(97, 108);
            this.pictureBox126.Name = "pictureBox126";
            this.pictureBox126.Size = new System.Drawing.Size(1, 2);
            this.pictureBox126.TabIndex = 450;
            this.pictureBox126.TabStop = false;
            // 
            // pictureBox127
            // 
            this.pictureBox127.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox127.Location = new System.Drawing.Point(89, 100);
            this.pictureBox127.Name = "pictureBox127";
            this.pictureBox127.Size = new System.Drawing.Size(1, 2);
            this.pictureBox127.TabIndex = 449;
            this.pictureBox127.TabStop = false;
            // 
            // pictureBox128
            // 
            this.pictureBox128.BackColor = System.Drawing.Color.Blue;
            this.pictureBox128.Location = new System.Drawing.Point(81, 92);
            this.pictureBox128.Name = "pictureBox128";
            this.pictureBox128.Size = new System.Drawing.Size(1, 2);
            this.pictureBox128.TabIndex = 448;
            this.pictureBox128.TabStop = false;
            // 
            // pictureBox129
            // 
            this.pictureBox129.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox129.Location = new System.Drawing.Point(73, 84);
            this.pictureBox129.Name = "pictureBox129";
            this.pictureBox129.Size = new System.Drawing.Size(1, 2);
            this.pictureBox129.TabIndex = 447;
            this.pictureBox129.TabStop = false;
            // 
            // pictureBox116
            // 
            this.pictureBox116.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox116.Location = new System.Drawing.Point(-6, 184);
            this.pictureBox116.Name = "pictureBox116";
            this.pictureBox116.Size = new System.Drawing.Size(1, 2);
            this.pictureBox116.TabIndex = 446;
            this.pictureBox116.TabStop = false;
            // 
            // pictureBox117
            // 
            this.pictureBox117.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox117.Location = new System.Drawing.Point(-14, 176);
            this.pictureBox117.Name = "pictureBox117";
            this.pictureBox117.Size = new System.Drawing.Size(1, 2);
            this.pictureBox117.TabIndex = 445;
            this.pictureBox117.TabStop = false;
            // 
            // pictureBox118
            // 
            this.pictureBox118.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox118.Location = new System.Drawing.Point(-22, 168);
            this.pictureBox118.Name = "pictureBox118";
            this.pictureBox118.Size = new System.Drawing.Size(1, 2);
            this.pictureBox118.TabIndex = 444;
            this.pictureBox118.TabStop = false;
            // 
            // pictureBox119
            // 
            this.pictureBox119.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox119.Location = new System.Drawing.Point(-30, 160);
            this.pictureBox119.Name = "pictureBox119";
            this.pictureBox119.Size = new System.Drawing.Size(1, 2);
            this.pictureBox119.TabIndex = 443;
            this.pictureBox119.TabStop = false;
            // 
            // pictureBox120
            // 
            this.pictureBox120.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox120.Location = new System.Drawing.Point(-38, 152);
            this.pictureBox120.Name = "pictureBox120";
            this.pictureBox120.Size = new System.Drawing.Size(1, 2);
            this.pictureBox120.TabIndex = 442;
            this.pictureBox120.TabStop = false;
            // 
            // pictureBox121
            // 
            this.pictureBox121.BackColor = System.Drawing.Color.Blue;
            this.pictureBox121.Location = new System.Drawing.Point(-46, 144);
            this.pictureBox121.Name = "pictureBox121";
            this.pictureBox121.Size = new System.Drawing.Size(1, 2);
            this.pictureBox121.TabIndex = 441;
            this.pictureBox121.TabStop = false;
            // 
            // pictureBox122
            // 
            this.pictureBox122.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox122.Location = new System.Drawing.Point(-54, 136);
            this.pictureBox122.Name = "pictureBox122";
            this.pictureBox122.Size = new System.Drawing.Size(1, 2);
            this.pictureBox122.TabIndex = 440;
            this.pictureBox122.TabStop = false;
            // 
            // pictureBox109
            // 
            this.pictureBox109.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox109.Location = new System.Drawing.Point(113, 124);
            this.pictureBox109.Name = "pictureBox109";
            this.pictureBox109.Size = new System.Drawing.Size(1, 2);
            this.pictureBox109.TabIndex = 439;
            this.pictureBox109.TabStop = false;
            // 
            // pictureBox110
            // 
            this.pictureBox110.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox110.Location = new System.Drawing.Point(105, 116);
            this.pictureBox110.Name = "pictureBox110";
            this.pictureBox110.Size = new System.Drawing.Size(1, 2);
            this.pictureBox110.TabIndex = 438;
            this.pictureBox110.TabStop = false;
            // 
            // pictureBox111
            // 
            this.pictureBox111.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox111.Location = new System.Drawing.Point(97, 108);
            this.pictureBox111.Name = "pictureBox111";
            this.pictureBox111.Size = new System.Drawing.Size(1, 2);
            this.pictureBox111.TabIndex = 437;
            this.pictureBox111.TabStop = false;
            // 
            // pictureBox112
            // 
            this.pictureBox112.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox112.Location = new System.Drawing.Point(89, 100);
            this.pictureBox112.Name = "pictureBox112";
            this.pictureBox112.Size = new System.Drawing.Size(1, 2);
            this.pictureBox112.TabIndex = 436;
            this.pictureBox112.TabStop = false;
            // 
            // pictureBox113
            // 
            this.pictureBox113.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox113.Location = new System.Drawing.Point(81, 92);
            this.pictureBox113.Name = "pictureBox113";
            this.pictureBox113.Size = new System.Drawing.Size(1, 2);
            this.pictureBox113.TabIndex = 435;
            this.pictureBox113.TabStop = false;
            // 
            // pictureBox114
            // 
            this.pictureBox114.BackColor = System.Drawing.Color.Blue;
            this.pictureBox114.Location = new System.Drawing.Point(73, 84);
            this.pictureBox114.Name = "pictureBox114";
            this.pictureBox114.Size = new System.Drawing.Size(1, 2);
            this.pictureBox114.TabIndex = 434;
            this.pictureBox114.TabStop = false;
            // 
            // pictureBox115
            // 
            this.pictureBox115.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox115.Location = new System.Drawing.Point(65, 76);
            this.pictureBox115.Name = "pictureBox115";
            this.pictureBox115.Size = new System.Drawing.Size(1, 2);
            this.pictureBox115.TabIndex = 433;
            this.pictureBox115.TabStop = false;
            // 
            // pictureBox108
            // 
            this.pictureBox108.BackColor = System.Drawing.Color.Crimson;
            this.pictureBox108.Location = new System.Drawing.Point(137, 149);
            this.pictureBox108.Name = "pictureBox108";
            this.pictureBox108.Size = new System.Drawing.Size(1, 2);
            this.pictureBox108.TabIndex = 432;
            this.pictureBox108.TabStop = false;
            // 
            // pictureBox107
            // 
            this.pictureBox107.BackColor = System.Drawing.Color.SpringGreen;
            this.pictureBox107.Location = new System.Drawing.Point(129, 141);
            this.pictureBox107.Name = "pictureBox107";
            this.pictureBox107.Size = new System.Drawing.Size(1, 2);
            this.pictureBox107.TabIndex = 431;
            this.pictureBox107.TabStop = false;
            // 
            // pictureBox106
            // 
            this.pictureBox106.BackColor = System.Drawing.Color.Magenta;
            this.pictureBox106.Location = new System.Drawing.Point(121, 133);
            this.pictureBox106.Name = "pictureBox106";
            this.pictureBox106.Size = new System.Drawing.Size(1, 2);
            this.pictureBox106.TabIndex = 430;
            this.pictureBox106.TabStop = false;
            // 
            // pictureBox105
            // 
            this.pictureBox105.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox105.Location = new System.Drawing.Point(113, 125);
            this.pictureBox105.Name = "pictureBox105";
            this.pictureBox105.Size = new System.Drawing.Size(1, 2);
            this.pictureBox105.TabIndex = 429;
            this.pictureBox105.TabStop = false;
            // 
            // pictureBox104
            // 
            this.pictureBox104.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pictureBox104.Location = new System.Drawing.Point(105, 117);
            this.pictureBox104.Name = "pictureBox104";
            this.pictureBox104.Size = new System.Drawing.Size(1, 2);
            this.pictureBox104.TabIndex = 428;
            this.pictureBox104.TabStop = false;
            // 
            // pictureBox103
            // 
            this.pictureBox103.BackColor = System.Drawing.Color.Blue;
            this.pictureBox103.Location = new System.Drawing.Point(97, 109);
            this.pictureBox103.Name = "pictureBox103";
            this.pictureBox103.Size = new System.Drawing.Size(1, 2);
            this.pictureBox103.TabIndex = 427;
            this.pictureBox103.TabStop = false;
            // 
            // pictureBox102
            // 
            this.pictureBox102.BackColor = System.Drawing.Color.Cyan;
            this.pictureBox102.Location = new System.Drawing.Point(89, 101);
            this.pictureBox102.Name = "pictureBox102";
            this.pictureBox102.Size = new System.Drawing.Size(1, 2);
            this.pictureBox102.TabIndex = 426;
            this.pictureBox102.TabStop = false;
            // 
            // pictureBox101
            // 
            this.pictureBox101.BackColor = System.Drawing.Color.Gold;
            this.pictureBox101.Location = new System.Drawing.Point(-47, 39);
            this.pictureBox101.Name = "pictureBox101";
            this.pictureBox101.Size = new System.Drawing.Size(1, 1);
            this.pictureBox101.TabIndex = 425;
            this.pictureBox101.TabStop = false;
            // 
            // pictureBox100
            // 
            this.pictureBox100.BackColor = System.Drawing.Color.Lime;
            this.pictureBox100.Location = new System.Drawing.Point(-6, 27);
            this.pictureBox100.Name = "pictureBox100";
            this.pictureBox100.Size = new System.Drawing.Size(1, 1);
            this.pictureBox100.TabIndex = 424;
            this.pictureBox100.TabStop = false;
            // 
            // pictureBox89
            // 
            this.pictureBox89.Location = new System.Drawing.Point(232, 116);
            this.pictureBox89.Name = "pictureBox89";
            this.pictureBox89.Size = new System.Drawing.Size(100, 50);
            this.pictureBox89.TabIndex = 423;
            this.pictureBox89.TabStop = false;
            // 
            // pictureBox90
            // 
            this.pictureBox90.Location = new System.Drawing.Point(224, 108);
            this.pictureBox90.Name = "pictureBox90";
            this.pictureBox90.Size = new System.Drawing.Size(100, 50);
            this.pictureBox90.TabIndex = 422;
            this.pictureBox90.TabStop = false;
            // 
            // pictureBox91
            // 
            this.pictureBox91.Location = new System.Drawing.Point(216, 100);
            this.pictureBox91.Name = "pictureBox91";
            this.pictureBox91.Size = new System.Drawing.Size(100, 50);
            this.pictureBox91.TabIndex = 421;
            this.pictureBox91.TabStop = false;
            // 
            // pictureBox92
            // 
            this.pictureBox92.Location = new System.Drawing.Point(208, 92);
            this.pictureBox92.Name = "pictureBox92";
            this.pictureBox92.Size = new System.Drawing.Size(100, 50);
            this.pictureBox92.TabIndex = 420;
            this.pictureBox92.TabStop = false;
            // 
            // pictureBox93
            // 
            this.pictureBox93.Location = new System.Drawing.Point(162, 84);
            this.pictureBox93.Name = "pictureBox93";
            this.pictureBox93.Size = new System.Drawing.Size(100, 50);
            this.pictureBox93.TabIndex = 419;
            this.pictureBox93.TabStop = false;
            // 
            // pictureBox94
            // 
            this.pictureBox94.Location = new System.Drawing.Point(154, 76);
            this.pictureBox94.Name = "pictureBox94";
            this.pictureBox94.Size = new System.Drawing.Size(100, 50);
            this.pictureBox94.TabIndex = 418;
            this.pictureBox94.TabStop = false;
            // 
            // pictureBox95
            // 
            this.pictureBox95.Location = new System.Drawing.Point(210, 65);
            this.pictureBox95.Name = "pictureBox95";
            this.pictureBox95.Size = new System.Drawing.Size(100, 50);
            this.pictureBox95.TabIndex = 417;
            this.pictureBox95.TabStop = false;
            // 
            // pictureBox96
            // 
            this.pictureBox96.Location = new System.Drawing.Point(232, 59);
            this.pictureBox96.Name = "pictureBox96";
            this.pictureBox96.Size = new System.Drawing.Size(100, 50);
            this.pictureBox96.TabIndex = 416;
            this.pictureBox96.TabStop = false;
            // 
            // pictureBox97
            // 
            this.pictureBox97.Location = new System.Drawing.Point(224, 51);
            this.pictureBox97.Name = "pictureBox97";
            this.pictureBox97.Size = new System.Drawing.Size(100, 50);
            this.pictureBox97.TabIndex = 415;
            this.pictureBox97.TabStop = false;
            // 
            // pictureBox98
            // 
            this.pictureBox98.Location = new System.Drawing.Point(216, 43);
            this.pictureBox98.Name = "pictureBox98";
            this.pictureBox98.Size = new System.Drawing.Size(100, 50);
            this.pictureBox98.TabIndex = 414;
            this.pictureBox98.TabStop = false;
            // 
            // pictureBox99
            // 
            this.pictureBox99.Location = new System.Drawing.Point(202, 208);
            this.pictureBox99.Name = "pictureBox99";
            this.pictureBox99.Size = new System.Drawing.Size(100, 50);
            this.pictureBox99.TabIndex = 413;
            this.pictureBox99.TabStop = false;
            // 
            // pictureBox78
            // 
            this.pictureBox78.Location = new System.Drawing.Point(224, 108);
            this.pictureBox78.Name = "pictureBox78";
            this.pictureBox78.Size = new System.Drawing.Size(100, 50);
            this.pictureBox78.TabIndex = 412;
            this.pictureBox78.TabStop = false;
            // 
            // pictureBox79
            // 
            this.pictureBox79.Location = new System.Drawing.Point(216, 100);
            this.pictureBox79.Name = "pictureBox79";
            this.pictureBox79.Size = new System.Drawing.Size(100, 50);
            this.pictureBox79.TabIndex = 411;
            this.pictureBox79.TabStop = false;
            // 
            // pictureBox80
            // 
            this.pictureBox80.Location = new System.Drawing.Point(208, 92);
            this.pictureBox80.Name = "pictureBox80";
            this.pictureBox80.Size = new System.Drawing.Size(100, 50);
            this.pictureBox80.TabIndex = 410;
            this.pictureBox80.TabStop = false;
            // 
            // pictureBox81
            // 
            this.pictureBox81.Location = new System.Drawing.Point(162, 84);
            this.pictureBox81.Name = "pictureBox81";
            this.pictureBox81.Size = new System.Drawing.Size(100, 50);
            this.pictureBox81.TabIndex = 409;
            this.pictureBox81.TabStop = false;
            // 
            // pictureBox82
            // 
            this.pictureBox82.Location = new System.Drawing.Point(154, 76);
            this.pictureBox82.Name = "pictureBox82";
            this.pictureBox82.Size = new System.Drawing.Size(100, 50);
            this.pictureBox82.TabIndex = 408;
            this.pictureBox82.TabStop = false;
            // 
            // pictureBox83
            // 
            this.pictureBox83.Location = new System.Drawing.Point(210, 65);
            this.pictureBox83.Name = "pictureBox83";
            this.pictureBox83.Size = new System.Drawing.Size(100, 50);
            this.pictureBox83.TabIndex = 407;
            this.pictureBox83.TabStop = false;
            // 
            // pictureBox84
            // 
            this.pictureBox84.Location = new System.Drawing.Point(232, 59);
            this.pictureBox84.Name = "pictureBox84";
            this.pictureBox84.Size = new System.Drawing.Size(100, 50);
            this.pictureBox84.TabIndex = 406;
            this.pictureBox84.TabStop = false;
            // 
            // pictureBox85
            // 
            this.pictureBox85.Location = new System.Drawing.Point(224, 51);
            this.pictureBox85.Name = "pictureBox85";
            this.pictureBox85.Size = new System.Drawing.Size(100, 50);
            this.pictureBox85.TabIndex = 405;
            this.pictureBox85.TabStop = false;
            // 
            // pictureBox86
            // 
            this.pictureBox86.Location = new System.Drawing.Point(216, 43);
            this.pictureBox86.Name = "pictureBox86";
            this.pictureBox86.Size = new System.Drawing.Size(100, 50);
            this.pictureBox86.TabIndex = 404;
            this.pictureBox86.TabStop = false;
            // 
            // pictureBox87
            // 
            this.pictureBox87.Location = new System.Drawing.Point(208, 35);
            this.pictureBox87.Name = "pictureBox87";
            this.pictureBox87.Size = new System.Drawing.Size(100, 50);
            this.pictureBox87.TabIndex = 403;
            this.pictureBox87.TabStop = false;
            // 
            // pictureBox88
            // 
            this.pictureBox88.Location = new System.Drawing.Point(194, 200);
            this.pictureBox88.Name = "pictureBox88";
            this.pictureBox88.Size = new System.Drawing.Size(100, 50);
            this.pictureBox88.TabIndex = 402;
            this.pictureBox88.TabStop = false;
            // 
            // pictureBox67
            // 
            this.pictureBox67.Location = new System.Drawing.Point(216, 100);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(100, 50);
            this.pictureBox67.TabIndex = 401;
            this.pictureBox67.TabStop = false;
            // 
            // pictureBox68
            // 
            this.pictureBox68.Location = new System.Drawing.Point(208, 92);
            this.pictureBox68.Name = "pictureBox68";
            this.pictureBox68.Size = new System.Drawing.Size(100, 50);
            this.pictureBox68.TabIndex = 400;
            this.pictureBox68.TabStop = false;
            // 
            // pictureBox69
            // 
            this.pictureBox69.Location = new System.Drawing.Point(162, 84);
            this.pictureBox69.Name = "pictureBox69";
            this.pictureBox69.Size = new System.Drawing.Size(100, 50);
            this.pictureBox69.TabIndex = 399;
            this.pictureBox69.TabStop = false;
            // 
            // pictureBox70
            // 
            this.pictureBox70.Location = new System.Drawing.Point(154, 76);
            this.pictureBox70.Name = "pictureBox70";
            this.pictureBox70.Size = new System.Drawing.Size(100, 50);
            this.pictureBox70.TabIndex = 398;
            this.pictureBox70.TabStop = false;
            // 
            // pictureBox71
            // 
            this.pictureBox71.Location = new System.Drawing.Point(210, 65);
            this.pictureBox71.Name = "pictureBox71";
            this.pictureBox71.Size = new System.Drawing.Size(100, 50);
            this.pictureBox71.TabIndex = 397;
            this.pictureBox71.TabStop = false;
            // 
            // pictureBox72
            // 
            this.pictureBox72.Location = new System.Drawing.Point(232, 59);
            this.pictureBox72.Name = "pictureBox72";
            this.pictureBox72.Size = new System.Drawing.Size(100, 50);
            this.pictureBox72.TabIndex = 396;
            this.pictureBox72.TabStop = false;
            // 
            // pictureBox73
            // 
            this.pictureBox73.Location = new System.Drawing.Point(224, 51);
            this.pictureBox73.Name = "pictureBox73";
            this.pictureBox73.Size = new System.Drawing.Size(100, 50);
            this.pictureBox73.TabIndex = 395;
            this.pictureBox73.TabStop = false;
            // 
            // pictureBox74
            // 
            this.pictureBox74.Location = new System.Drawing.Point(216, 43);
            this.pictureBox74.Name = "pictureBox74";
            this.pictureBox74.Size = new System.Drawing.Size(100, 50);
            this.pictureBox74.TabIndex = 394;
            this.pictureBox74.TabStop = false;
            // 
            // pictureBox75
            // 
            this.pictureBox75.Location = new System.Drawing.Point(208, 35);
            this.pictureBox75.Name = "pictureBox75";
            this.pictureBox75.Size = new System.Drawing.Size(100, 50);
            this.pictureBox75.TabIndex = 393;
            this.pictureBox75.TabStop = false;
            // 
            // pictureBox76
            // 
            this.pictureBox76.Location = new System.Drawing.Point(200, 27);
            this.pictureBox76.Name = "pictureBox76";
            this.pictureBox76.Size = new System.Drawing.Size(100, 50);
            this.pictureBox76.TabIndex = 392;
            this.pictureBox76.TabStop = false;
            // 
            // pictureBox77
            // 
            this.pictureBox77.Location = new System.Drawing.Point(186, 192);
            this.pictureBox77.Name = "pictureBox77";
            this.pictureBox77.Size = new System.Drawing.Size(100, 50);
            this.pictureBox77.TabIndex = 391;
            this.pictureBox77.TabStop = false;
            // 
            // pictureBox56
            // 
            this.pictureBox56.Location = new System.Drawing.Point(208, 92);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(100, 50);
            this.pictureBox56.TabIndex = 390;
            this.pictureBox56.TabStop = false;
            // 
            // pictureBox57
            // 
            this.pictureBox57.Location = new System.Drawing.Point(162, 84);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(100, 50);
            this.pictureBox57.TabIndex = 389;
            this.pictureBox57.TabStop = false;
            // 
            // pictureBox58
            // 
            this.pictureBox58.Location = new System.Drawing.Point(154, 76);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(100, 50);
            this.pictureBox58.TabIndex = 388;
            this.pictureBox58.TabStop = false;
            // 
            // pictureBox59
            // 
            this.pictureBox59.Location = new System.Drawing.Point(210, 65);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(100, 50);
            this.pictureBox59.TabIndex = 387;
            this.pictureBox59.TabStop = false;
            // 
            // pictureBox60
            // 
            this.pictureBox60.Location = new System.Drawing.Point(232, 59);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(100, 50);
            this.pictureBox60.TabIndex = 386;
            this.pictureBox60.TabStop = false;
            // 
            // pictureBox61
            // 
            this.pictureBox61.Location = new System.Drawing.Point(224, 51);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(100, 50);
            this.pictureBox61.TabIndex = 385;
            this.pictureBox61.TabStop = false;
            // 
            // pictureBox62
            // 
            this.pictureBox62.Location = new System.Drawing.Point(216, 43);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(100, 50);
            this.pictureBox62.TabIndex = 384;
            this.pictureBox62.TabStop = false;
            // 
            // pictureBox63
            // 
            this.pictureBox63.Location = new System.Drawing.Point(208, 35);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(100, 50);
            this.pictureBox63.TabIndex = 383;
            this.pictureBox63.TabStop = false;
            // 
            // pictureBox64
            // 
            this.pictureBox64.Location = new System.Drawing.Point(200, 27);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(100, 50);
            this.pictureBox64.TabIndex = 382;
            this.pictureBox64.TabStop = false;
            // 
            // pictureBox66
            // 
            this.pictureBox66.Location = new System.Drawing.Point(178, 184);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(100, 50);
            this.pictureBox66.TabIndex = 380;
            this.pictureBox66.TabStop = false;
            // 
            // pictureBox50
            // 
            this.pictureBox50.Location = new System.Drawing.Point(216, 43);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(100, 50);
            this.pictureBox50.TabIndex = 374;
            this.pictureBox50.TabStop = false;
            // 
            // pictureBox65
            // 
            this.pictureBox65.Location = new System.Drawing.Point(192, 19);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(100, 50);
            this.pictureBox65.TabIndex = 381;
            this.pictureBox65.TabStop = false;
            // 
            // pictureBox45
            // 
            this.pictureBox45.Location = new System.Drawing.Point(162, 84);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(100, 50);
            this.pictureBox45.TabIndex = 379;
            this.pictureBox45.TabStop = false;
            // 
            // pictureBox46
            // 
            this.pictureBox46.Location = new System.Drawing.Point(154, 76);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(100, 50);
            this.pictureBox46.TabIndex = 378;
            this.pictureBox46.TabStop = false;
            // 
            // pictureBox47
            // 
            this.pictureBox47.Location = new System.Drawing.Point(210, 65);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(100, 50);
            this.pictureBox47.TabIndex = 377;
            this.pictureBox47.TabStop = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.Location = new System.Drawing.Point(232, 59);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(100, 50);
            this.pictureBox48.TabIndex = 376;
            this.pictureBox48.TabStop = false;
            // 
            // pictureBox49
            // 
            this.pictureBox49.Location = new System.Drawing.Point(224, 51);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(100, 50);
            this.pictureBox49.TabIndex = 375;
            this.pictureBox49.TabStop = false;
            // 
            // pictureBox51
            // 
            this.pictureBox51.Location = new System.Drawing.Point(208, 35);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(100, 50);
            this.pictureBox51.TabIndex = 373;
            this.pictureBox51.TabStop = false;
            // 
            // pictureBox52
            // 
            this.pictureBox52.Location = new System.Drawing.Point(200, 27);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(100, 50);
            this.pictureBox52.TabIndex = 372;
            this.pictureBox52.TabStop = false;
            // 
            // pictureBox53
            // 
            this.pictureBox53.Location = new System.Drawing.Point(192, 19);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(100, 50);
            this.pictureBox53.TabIndex = 371;
            this.pictureBox53.TabStop = false;
            // 
            // pictureBox54
            // 
            this.pictureBox54.Location = new System.Drawing.Point(184, 11);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(100, 50);
            this.pictureBox54.TabIndex = 370;
            this.pictureBox54.TabStop = false;
            // 
            // pictureBox55
            // 
            this.pictureBox55.Location = new System.Drawing.Point(170, 176);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(100, 50);
            this.pictureBox55.TabIndex = 369;
            this.pictureBox55.TabStop = false;
            // 
            // pictureBox34
            // 
            this.pictureBox34.Location = new System.Drawing.Point(154, 76);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(100, 50);
            this.pictureBox34.TabIndex = 368;
            this.pictureBox34.TabStop = false;
            // 
            // pictureBox35
            // 
            this.pictureBox35.Location = new System.Drawing.Point(210, 65);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(100, 50);
            this.pictureBox35.TabIndex = 367;
            this.pictureBox35.TabStop = false;
            // 
            // pictureBox36
            // 
            this.pictureBox36.Location = new System.Drawing.Point(232, 59);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(100, 50);
            this.pictureBox36.TabIndex = 366;
            this.pictureBox36.TabStop = false;
            // 
            // pictureBox37
            // 
            this.pictureBox37.Location = new System.Drawing.Point(224, 51);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(100, 50);
            this.pictureBox37.TabIndex = 365;
            this.pictureBox37.TabStop = false;
            // 
            // pictureBox38
            // 
            this.pictureBox38.Location = new System.Drawing.Point(216, 43);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(100, 50);
            this.pictureBox38.TabIndex = 364;
            this.pictureBox38.TabStop = false;
            // 
            // pictureBox39
            // 
            this.pictureBox39.Location = new System.Drawing.Point(208, 35);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(100, 50);
            this.pictureBox39.TabIndex = 363;
            this.pictureBox39.TabStop = false;
            // 
            // pictureBox40
            // 
            this.pictureBox40.Location = new System.Drawing.Point(200, 27);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(100, 50);
            this.pictureBox40.TabIndex = 362;
            this.pictureBox40.TabStop = false;
            // 
            // pictureBox41
            // 
            this.pictureBox41.Location = new System.Drawing.Point(192, 19);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(100, 50);
            this.pictureBox41.TabIndex = 361;
            this.pictureBox41.TabStop = false;
            // 
            // pictureBox42
            // 
            this.pictureBox42.Location = new System.Drawing.Point(184, 11);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(100, 50);
            this.pictureBox42.TabIndex = 360;
            this.pictureBox42.TabStop = false;
            // 
            // pictureBox43
            // 
            this.pictureBox43.Location = new System.Drawing.Point(176, 3);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(100, 50);
            this.pictureBox43.TabIndex = 359;
            this.pictureBox43.TabStop = false;
            // 
            // pictureBox44
            // 
            this.pictureBox44.Location = new System.Drawing.Point(162, 168);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(100, 50);
            this.pictureBox44.TabIndex = 358;
            this.pictureBox44.TabStop = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Location = new System.Drawing.Point(210, 65);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(100, 50);
            this.pictureBox23.TabIndex = 357;
            this.pictureBox23.TabStop = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Location = new System.Drawing.Point(232, 59);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(100, 50);
            this.pictureBox24.TabIndex = 356;
            this.pictureBox24.TabStop = false;
            // 
            // pictureBox25
            // 
            this.pictureBox25.Location = new System.Drawing.Point(224, 51);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(100, 50);
            this.pictureBox25.TabIndex = 355;
            this.pictureBox25.TabStop = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.Location = new System.Drawing.Point(216, 43);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(100, 50);
            this.pictureBox26.TabIndex = 354;
            this.pictureBox26.TabStop = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.Location = new System.Drawing.Point(208, 35);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(100, 50);
            this.pictureBox27.TabIndex = 353;
            this.pictureBox27.TabStop = false;
            // 
            // pictureBox28
            // 
            this.pictureBox28.Location = new System.Drawing.Point(200, 27);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(100, 50);
            this.pictureBox28.TabIndex = 352;
            this.pictureBox28.TabStop = false;
            // 
            // pictureBox29
            // 
            this.pictureBox29.Location = new System.Drawing.Point(192, 19);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(100, 50);
            this.pictureBox29.TabIndex = 351;
            this.pictureBox29.TabStop = false;
            // 
            // pictureBox30
            // 
            this.pictureBox30.Location = new System.Drawing.Point(184, 11);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(100, 50);
            this.pictureBox30.TabIndex = 350;
            this.pictureBox30.TabStop = false;
            // 
            // pictureBox31
            // 
            this.pictureBox31.Location = new System.Drawing.Point(176, 3);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(100, 50);
            this.pictureBox31.TabIndex = 349;
            this.pictureBox31.TabStop = false;
            // 
            // pictureBox32
            // 
            this.pictureBox32.Location = new System.Drawing.Point(168, -5);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(100, 50);
            this.pictureBox32.TabIndex = 348;
            this.pictureBox32.TabStop = false;
            // 
            // pictureBox33
            // 
            this.pictureBox33.Location = new System.Drawing.Point(154, 160);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(100, 50);
            this.pictureBox33.TabIndex = 347;
            this.pictureBox33.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Location = new System.Drawing.Point(232, 59);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(100, 50);
            this.pictureBox12.TabIndex = 346;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Location = new System.Drawing.Point(224, 51);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(100, 50);
            this.pictureBox13.TabIndex = 345;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Location = new System.Drawing.Point(216, 43);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(100, 50);
            this.pictureBox14.TabIndex = 344;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Location = new System.Drawing.Point(208, 35);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(100, 50);
            this.pictureBox15.TabIndex = 343;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Location = new System.Drawing.Point(200, 27);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(100, 50);
            this.pictureBox16.TabIndex = 342;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Location = new System.Drawing.Point(192, 19);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(100, 50);
            this.pictureBox17.TabIndex = 341;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Location = new System.Drawing.Point(184, 11);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(100, 50);
            this.pictureBox18.TabIndex = 340;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Location = new System.Drawing.Point(176, 3);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(100, 50);
            this.pictureBox19.TabIndex = 339;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Location = new System.Drawing.Point(168, -5);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(100, 50);
            this.pictureBox20.TabIndex = 338;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Location = new System.Drawing.Point(160, -13);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(100, 50);
            this.pictureBox21.TabIndex = 337;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Location = new System.Drawing.Point(146, 152);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(100, 50);
            this.pictureBox22.TabIndex = 336;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Location = new System.Drawing.Point(210, 129);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(100, 50);
            this.pictureBox11.TabIndex = 335;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(224, 115);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(100, 50);
            this.pictureBox9.TabIndex = 333;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(224, 105);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(100, 50);
            this.pictureBox8.TabIndex = 332;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(216, 97);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(100, 50);
            this.pictureBox7.TabIndex = 331;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(238, 91);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(100, 50);
            this.pictureBox6.TabIndex = 330;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(192, 83);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(100, 50);
            this.pictureBox5.TabIndex = 329;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(184, 75);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 50);
            this.pictureBox4.TabIndex = 328;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(176, 67);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 50);
            this.pictureBox3.TabIndex = 327;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(168, 59);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.TabIndex = 326;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(210, 223);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 325;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Location = new System.Drawing.Point(232, 123);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(100, 50);
            this.pictureBox10.TabIndex = 334;
            this.pictureBox10.TabStop = false;
            // 
            // Player
            // 
            this.Player.BackColor = System.Drawing.Color.Gold;
            this.Player.Location = new System.Drawing.Point(81, 111);
            this.Player.Name = "Player";
            this.Player.Size = new System.Drawing.Size(7, 7);
            this.Player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Player.TabIndex = 324;
            this.Player.TabStop = false;
            // 
            // Bsecond
            // 
            this.Bsecond.Interval = 1000;
            this.Bsecond.Tick += new System.EventHandler(this.Bsecond_Tick);
            // 
            // Slow
            // 
            this.Slow.Interval = 5;
            this.Slow.Tick += new System.EventHandler(this.Slow_Tick);
            // 
            // Normal
            // 
            this.Normal.Enabled = true;
            this.Normal.Interval = 5;
            this.Normal.Tick += new System.EventHandler(this.Normal_Tick);
            // 
            // Second
            // 
            this.Second.Enabled = true;
            this.Second.Interval = 1000;
            this.Second.Tick += new System.EventHandler(this.Second_Tick);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Trace
            // 
            this.Trace.Interval = 5;
            this.Trace.Tick += new System.EventHandler(this.Trace_Tick);
            // 
            // Randd
            // 
            this.Randd.Enabled = true;
            this.Randd.Interval = 2500;
            this.Randd.Tick += new System.EventHandler(this.Randd_Tick);
            // 
            // Fast
            // 
            this.Fast.Interval = 1;
            this.Fast.Tick += new System.EventHandler(this.Fast_Tick);
            // 
            // BackG
            // 
            this.BackG.Enabled = true;
            this.BackG.Interval = 5;
            this.BackG.Tick += new System.EventHandler(this.BackG_Tick);
            // 
            // Nice
            // 
            this.Nice.Interval = 1;
            this.Nice.Tick += new System.EventHandler(this.Nice_Tick);
            // 
            // Boom
            // 
            this.Boom.Interval = 500;
            this.Boom.Tick += new System.EventHandler(this.Boom_Tick);
            // 
            // Remix
            // 
            this.Remix.Interval = 5;
            this.Remix.Tick += new System.EventHandler(this.Remix_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(194, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 15);
            this.label1.TabIndex = 531;
            this.label1.Text = "123";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // database1DataSet
            // 
            this.database1DataSet.DataSetName = "Database1DataSet";
            this.database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            this.tableBindingSource.DataSource = this.database1DataSet;
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TableTableAdapter = this.tableTableAdapter;
            this.tableAdapterManager.UpdateOrder = HideBullet.Database1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tableDataGridView
            // 
            this.tableDataGridView.AutoGenerateColumns = false;
            this.tableDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.tableDataGridView.DataSource = this.tableBindingSource;
            this.tableDataGridView.Location = new System.Drawing.Point(10, 87);
            this.tableDataGridView.Name = "tableDataGridView";
            this.tableDataGridView.RowTemplate.Height = 24;
            this.tableDataGridView.Size = new System.Drawing.Size(244, 86);
            this.tableDataGridView.TabIndex = 534;
            this.tableDataGridView.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn1.HeaderText = "Name";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Time";
            this.dataGridViewTextBoxColumn2.HeaderText = "Time";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("jf open 粉圓 1.1", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(171, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 538;
            this.button1.Text = "登錄成績";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("jf open 粉圓 1.1", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(171, 59);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 539;
            this.button2.Text = "再玩一次";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("jf open 粉圓 1.1", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(12, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 17);
            this.label4.TabIndex = 540;
            this.label4.Text = "Name:";
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("jf open 粉圓 1.1", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(15, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 17);
            this.label5.TabIndex = 541;
            this.label5.Text = "Time:";
            this.label5.Visible = false;
            // 
            // nameTextBox1
            // 
            this.nameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tableBindingSource, "Name", true));
            this.nameTextBox1.Font = new System.Drawing.Font("jf open 粉圓 1.1", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.nameTextBox1.Location = new System.Drawing.Point(62, 33);
            this.nameTextBox1.Name = "nameTextBox1";
            this.nameTextBox1.Size = new System.Drawing.Size(100, 24);
            this.nameTextBox1.TabIndex = 543;
            this.nameTextBox1.Visible = false;
            // 
            // timeTextBox1
            // 
            this.timeTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tableBindingSource, "Time", true));
            this.timeTextBox1.Enabled = false;
            this.timeTextBox1.Font = new System.Drawing.Font("jf open 粉圓 1.1", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.timeTextBox1.Location = new System.Drawing.Point(62, 61);
            this.timeTextBox1.Name = "timeTextBox1";
            this.timeTextBox1.Size = new System.Drawing.Size(100, 24);
            this.timeTextBox1.TabIndex = 545;
            this.timeTextBox1.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.nameTextBox1);
            this.Controls.Add(this.timeTextBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(nameLabel);
            this.Controls.Add(timeLabel);
            this.Controls.Add(this.tableDataGridView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox200);
            this.Controls.Add(this.pictureBox201);
            this.Controls.Add(this.pictureBox202);
            this.Controls.Add(this.pictureBox203);
            this.Controls.Add(this.pictureBox204);
            this.Controls.Add(this.pictureBox205);
            this.Controls.Add(this.pictureBox206);
            this.Controls.Add(this.pictureBox193);
            this.Controls.Add(this.pictureBox194);
            this.Controls.Add(this.pictureBox195);
            this.Controls.Add(this.pictureBox196);
            this.Controls.Add(this.pictureBox197);
            this.Controls.Add(this.pictureBox198);
            this.Controls.Add(this.pictureBox199);
            this.Controls.Add(this.pictureBox186);
            this.Controls.Add(this.pictureBox187);
            this.Controls.Add(this.pictureBox188);
            this.Controls.Add(this.pictureBox189);
            this.Controls.Add(this.pictureBox190);
            this.Controls.Add(this.pictureBox191);
            this.Controls.Add(this.pictureBox192);
            this.Controls.Add(this.pictureBox179);
            this.Controls.Add(this.pictureBox180);
            this.Controls.Add(this.pictureBox181);
            this.Controls.Add(this.pictureBox182);
            this.Controls.Add(this.pictureBox183);
            this.Controls.Add(this.pictureBox184);
            this.Controls.Add(this.pictureBox185);
            this.Controls.Add(this.pictureBox172);
            this.Controls.Add(this.pictureBox173);
            this.Controls.Add(this.pictureBox174);
            this.Controls.Add(this.pictureBox175);
            this.Controls.Add(this.pictureBox176);
            this.Controls.Add(this.pictureBox177);
            this.Controls.Add(this.pictureBox178);
            this.Controls.Add(this.pictureBox165);
            this.Controls.Add(this.pictureBox166);
            this.Controls.Add(this.pictureBox167);
            this.Controls.Add(this.pictureBox168);
            this.Controls.Add(this.pictureBox169);
            this.Controls.Add(this.pictureBox170);
            this.Controls.Add(this.pictureBox171);
            this.Controls.Add(this.pictureBox158);
            this.Controls.Add(this.pictureBox159);
            this.Controls.Add(this.pictureBox160);
            this.Controls.Add(this.pictureBox161);
            this.Controls.Add(this.pictureBox162);
            this.Controls.Add(this.pictureBox163);
            this.Controls.Add(this.pictureBox164);
            this.Controls.Add(this.pictureBox151);
            this.Controls.Add(this.pictureBox152);
            this.Controls.Add(this.pictureBox153);
            this.Controls.Add(this.pictureBox154);
            this.Controls.Add(this.pictureBox155);
            this.Controls.Add(this.pictureBox156);
            this.Controls.Add(this.pictureBox157);
            this.Controls.Add(this.pictureBox144);
            this.Controls.Add(this.pictureBox145);
            this.Controls.Add(this.pictureBox146);
            this.Controls.Add(this.pictureBox147);
            this.Controls.Add(this.pictureBox148);
            this.Controls.Add(this.pictureBox149);
            this.Controls.Add(this.pictureBox150);
            this.Controls.Add(this.pictureBox137);
            this.Controls.Add(this.pictureBox138);
            this.Controls.Add(this.pictureBox139);
            this.Controls.Add(this.pictureBox140);
            this.Controls.Add(this.pictureBox141);
            this.Controls.Add(this.pictureBox142);
            this.Controls.Add(this.pictureBox143);
            this.Controls.Add(this.pictureBox130);
            this.Controls.Add(this.pictureBox131);
            this.Controls.Add(this.pictureBox132);
            this.Controls.Add(this.pictureBox133);
            this.Controls.Add(this.pictureBox134);
            this.Controls.Add(this.pictureBox135);
            this.Controls.Add(this.pictureBox136);
            this.Controls.Add(this.pictureBox123);
            this.Controls.Add(this.pictureBox124);
            this.Controls.Add(this.pictureBox125);
            this.Controls.Add(this.pictureBox126);
            this.Controls.Add(this.pictureBox127);
            this.Controls.Add(this.pictureBox128);
            this.Controls.Add(this.pictureBox129);
            this.Controls.Add(this.pictureBox116);
            this.Controls.Add(this.pictureBox117);
            this.Controls.Add(this.pictureBox118);
            this.Controls.Add(this.pictureBox119);
            this.Controls.Add(this.pictureBox120);
            this.Controls.Add(this.pictureBox121);
            this.Controls.Add(this.pictureBox122);
            this.Controls.Add(this.pictureBox109);
            this.Controls.Add(this.pictureBox110);
            this.Controls.Add(this.pictureBox111);
            this.Controls.Add(this.pictureBox112);
            this.Controls.Add(this.pictureBox113);
            this.Controls.Add(this.pictureBox114);
            this.Controls.Add(this.pictureBox115);
            this.Controls.Add(this.pictureBox108);
            this.Controls.Add(this.pictureBox107);
            this.Controls.Add(this.pictureBox106);
            this.Controls.Add(this.pictureBox105);
            this.Controls.Add(this.pictureBox104);
            this.Controls.Add(this.pictureBox103);
            this.Controls.Add(this.pictureBox102);
            this.Controls.Add(this.pictureBox101);
            this.Controls.Add(this.pictureBox100);
            this.Controls.Add(this.pictureBox89);
            this.Controls.Add(this.pictureBox90);
            this.Controls.Add(this.pictureBox91);
            this.Controls.Add(this.pictureBox92);
            this.Controls.Add(this.pictureBox93);
            this.Controls.Add(this.pictureBox94);
            this.Controls.Add(this.pictureBox95);
            this.Controls.Add(this.pictureBox96);
            this.Controls.Add(this.pictureBox97);
            this.Controls.Add(this.pictureBox98);
            this.Controls.Add(this.pictureBox99);
            this.Controls.Add(this.pictureBox78);
            this.Controls.Add(this.pictureBox79);
            this.Controls.Add(this.pictureBox80);
            this.Controls.Add(this.pictureBox81);
            this.Controls.Add(this.pictureBox82);
            this.Controls.Add(this.pictureBox83);
            this.Controls.Add(this.pictureBox84);
            this.Controls.Add(this.pictureBox85);
            this.Controls.Add(this.pictureBox86);
            this.Controls.Add(this.pictureBox87);
            this.Controls.Add(this.pictureBox88);
            this.Controls.Add(this.pictureBox67);
            this.Controls.Add(this.pictureBox68);
            this.Controls.Add(this.pictureBox69);
            this.Controls.Add(this.pictureBox70);
            this.Controls.Add(this.pictureBox71);
            this.Controls.Add(this.pictureBox72);
            this.Controls.Add(this.pictureBox73);
            this.Controls.Add(this.pictureBox74);
            this.Controls.Add(this.pictureBox75);
            this.Controls.Add(this.pictureBox76);
            this.Controls.Add(this.pictureBox77);
            this.Controls.Add(this.pictureBox56);
            this.Controls.Add(this.pictureBox57);
            this.Controls.Add(this.pictureBox58);
            this.Controls.Add(this.pictureBox59);
            this.Controls.Add(this.pictureBox60);
            this.Controls.Add(this.pictureBox61);
            this.Controls.Add(this.pictureBox62);
            this.Controls.Add(this.pictureBox63);
            this.Controls.Add(this.pictureBox64);
            this.Controls.Add(this.pictureBox66);
            this.Controls.Add(this.pictureBox50);
            this.Controls.Add(this.pictureBox65);
            this.Controls.Add(this.pictureBox45);
            this.Controls.Add(this.pictureBox46);
            this.Controls.Add(this.pictureBox47);
            this.Controls.Add(this.pictureBox48);
            this.Controls.Add(this.pictureBox49);
            this.Controls.Add(this.pictureBox51);
            this.Controls.Add(this.pictureBox52);
            this.Controls.Add(this.pictureBox53);
            this.Controls.Add(this.pictureBox54);
            this.Controls.Add(this.pictureBox55);
            this.Controls.Add(this.pictureBox34);
            this.Controls.Add(this.pictureBox35);
            this.Controls.Add(this.pictureBox36);
            this.Controls.Add(this.pictureBox37);
            this.Controls.Add(this.pictureBox38);
            this.Controls.Add(this.pictureBox39);
            this.Controls.Add(this.pictureBox40);
            this.Controls.Add(this.pictureBox41);
            this.Controls.Add(this.pictureBox42);
            this.Controls.Add(this.pictureBox43);
            this.Controls.Add(this.pictureBox44);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.pictureBox25);
            this.Controls.Add(this.pictureBox26);
            this.Controls.Add(this.pictureBox27);
            this.Controls.Add(this.pictureBox28);
            this.Controls.Add(this.pictureBox29);
            this.Controls.Add(this.pictureBox30);
            this.Controls.Add(this.pictureBox31);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.pictureBox33);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.Player);
            this.KeyPreview = true;
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox200)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox201)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox202)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox203)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox204)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox205)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox206)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox193)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox194)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox195)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox196)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox197)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox198)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox199)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox186)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox187)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox188)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox189)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox190)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox191)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox192)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox179)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox180)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox181)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox182)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox183)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox184)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox185)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox172)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox173)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox174)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox175)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox176)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox177)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox178)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox165)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox166)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox167)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox168)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox169)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox170)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox171)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox158)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox159)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox160)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox161)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox162)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox163)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox164)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox151)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox152)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox156)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox157)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox144)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox145)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox146)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox147)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox149)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox150)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox140)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox141)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox142)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox143)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox130)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox132)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox133)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox136)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox125)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox126)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox127)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox128)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox129)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox200;
        private System.Windows.Forms.PictureBox pictureBox201;
        private System.Windows.Forms.PictureBox pictureBox202;
        private System.Windows.Forms.PictureBox pictureBox203;
        private System.Windows.Forms.PictureBox pictureBox204;
        private System.Windows.Forms.PictureBox pictureBox205;
        private System.Windows.Forms.PictureBox pictureBox206;
        private System.Windows.Forms.PictureBox pictureBox193;
        private System.Windows.Forms.PictureBox pictureBox194;
        private System.Windows.Forms.PictureBox pictureBox195;
        private System.Windows.Forms.PictureBox pictureBox196;
        private System.Windows.Forms.PictureBox pictureBox197;
        private System.Windows.Forms.PictureBox pictureBox198;
        private System.Windows.Forms.PictureBox pictureBox199;
        private System.Windows.Forms.PictureBox pictureBox186;
        private System.Windows.Forms.PictureBox pictureBox187;
        private System.Windows.Forms.PictureBox pictureBox188;
        private System.Windows.Forms.PictureBox pictureBox189;
        private System.Windows.Forms.PictureBox pictureBox190;
        private System.Windows.Forms.PictureBox pictureBox191;
        private System.Windows.Forms.PictureBox pictureBox192;
        private System.Windows.Forms.PictureBox pictureBox179;
        private System.Windows.Forms.PictureBox pictureBox180;
        private System.Windows.Forms.PictureBox pictureBox181;
        private System.Windows.Forms.PictureBox pictureBox182;
        private System.Windows.Forms.PictureBox pictureBox183;
        private System.Windows.Forms.PictureBox pictureBox184;
        private System.Windows.Forms.PictureBox pictureBox185;
        private System.Windows.Forms.PictureBox pictureBox172;
        private System.Windows.Forms.PictureBox pictureBox173;
        private System.Windows.Forms.PictureBox pictureBox174;
        private System.Windows.Forms.PictureBox pictureBox175;
        private System.Windows.Forms.PictureBox pictureBox176;
        private System.Windows.Forms.PictureBox pictureBox177;
        private System.Windows.Forms.PictureBox pictureBox178;
        private System.Windows.Forms.PictureBox pictureBox165;
        private System.Windows.Forms.PictureBox pictureBox166;
        private System.Windows.Forms.PictureBox pictureBox167;
        private System.Windows.Forms.PictureBox pictureBox168;
        private System.Windows.Forms.PictureBox pictureBox169;
        private System.Windows.Forms.PictureBox pictureBox170;
        private System.Windows.Forms.PictureBox pictureBox171;
        private System.Windows.Forms.PictureBox pictureBox158;
        private System.Windows.Forms.PictureBox pictureBox159;
        private System.Windows.Forms.PictureBox pictureBox160;
        private System.Windows.Forms.PictureBox pictureBox161;
        private System.Windows.Forms.PictureBox pictureBox162;
        private System.Windows.Forms.PictureBox pictureBox163;
        private System.Windows.Forms.PictureBox pictureBox164;
        private System.Windows.Forms.PictureBox pictureBox151;
        private System.Windows.Forms.PictureBox pictureBox152;
        private System.Windows.Forms.PictureBox pictureBox153;
        private System.Windows.Forms.PictureBox pictureBox154;
        private System.Windows.Forms.PictureBox pictureBox155;
        private System.Windows.Forms.PictureBox pictureBox156;
        private System.Windows.Forms.PictureBox pictureBox157;
        private System.Windows.Forms.PictureBox pictureBox144;
        private System.Windows.Forms.PictureBox pictureBox145;
        private System.Windows.Forms.PictureBox pictureBox146;
        private System.Windows.Forms.PictureBox pictureBox147;
        private System.Windows.Forms.PictureBox pictureBox148;
        private System.Windows.Forms.PictureBox pictureBox149;
        private System.Windows.Forms.PictureBox pictureBox150;
        private System.Windows.Forms.PictureBox pictureBox137;
        private System.Windows.Forms.PictureBox pictureBox138;
        private System.Windows.Forms.PictureBox pictureBox139;
        private System.Windows.Forms.PictureBox pictureBox140;
        private System.Windows.Forms.PictureBox pictureBox141;
        private System.Windows.Forms.PictureBox pictureBox142;
        private System.Windows.Forms.PictureBox pictureBox143;
        private System.Windows.Forms.PictureBox pictureBox130;
        private System.Windows.Forms.PictureBox pictureBox131;
        private System.Windows.Forms.PictureBox pictureBox132;
        private System.Windows.Forms.PictureBox pictureBox133;
        private System.Windows.Forms.PictureBox pictureBox134;
        private System.Windows.Forms.PictureBox pictureBox135;
        private System.Windows.Forms.PictureBox pictureBox136;
        private System.Windows.Forms.PictureBox pictureBox123;
        private System.Windows.Forms.PictureBox pictureBox124;
        private System.Windows.Forms.PictureBox pictureBox125;
        private System.Windows.Forms.PictureBox pictureBox126;
        private System.Windows.Forms.PictureBox pictureBox127;
        private System.Windows.Forms.PictureBox pictureBox128;
        private System.Windows.Forms.PictureBox pictureBox129;
        private System.Windows.Forms.PictureBox pictureBox116;
        private System.Windows.Forms.PictureBox pictureBox117;
        private System.Windows.Forms.PictureBox pictureBox118;
        private System.Windows.Forms.PictureBox pictureBox119;
        private System.Windows.Forms.PictureBox pictureBox120;
        private System.Windows.Forms.PictureBox pictureBox121;
        private System.Windows.Forms.PictureBox pictureBox122;
        private System.Windows.Forms.PictureBox pictureBox109;
        private System.Windows.Forms.PictureBox pictureBox110;
        private System.Windows.Forms.PictureBox pictureBox111;
        private System.Windows.Forms.PictureBox pictureBox112;
        private System.Windows.Forms.PictureBox pictureBox113;
        private System.Windows.Forms.PictureBox pictureBox114;
        private System.Windows.Forms.PictureBox pictureBox115;
        private System.Windows.Forms.PictureBox pictureBox108;
        private System.Windows.Forms.PictureBox pictureBox107;
        private System.Windows.Forms.PictureBox pictureBox106;
        private System.Windows.Forms.PictureBox pictureBox105;
        private System.Windows.Forms.PictureBox pictureBox104;
        private System.Windows.Forms.PictureBox pictureBox103;
        private System.Windows.Forms.PictureBox pictureBox102;
        private System.Windows.Forms.PictureBox pictureBox101;
        private System.Windows.Forms.PictureBox pictureBox100;
        private System.Windows.Forms.PictureBox pictureBox89;
        private System.Windows.Forms.PictureBox pictureBox90;
        private System.Windows.Forms.PictureBox pictureBox91;
        private System.Windows.Forms.PictureBox pictureBox92;
        private System.Windows.Forms.PictureBox pictureBox93;
        private System.Windows.Forms.PictureBox pictureBox94;
        private System.Windows.Forms.PictureBox pictureBox95;
        private System.Windows.Forms.PictureBox pictureBox96;
        private System.Windows.Forms.PictureBox pictureBox97;
        private System.Windows.Forms.PictureBox pictureBox98;
        private System.Windows.Forms.PictureBox pictureBox99;
        private System.Windows.Forms.PictureBox pictureBox78;
        private System.Windows.Forms.PictureBox pictureBox79;
        private System.Windows.Forms.PictureBox pictureBox80;
        private System.Windows.Forms.PictureBox pictureBox81;
        private System.Windows.Forms.PictureBox pictureBox82;
        private System.Windows.Forms.PictureBox pictureBox83;
        private System.Windows.Forms.PictureBox pictureBox84;
        private System.Windows.Forms.PictureBox pictureBox85;
        private System.Windows.Forms.PictureBox pictureBox86;
        private System.Windows.Forms.PictureBox pictureBox87;
        private System.Windows.Forms.PictureBox pictureBox88;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.PictureBox pictureBox68;
        private System.Windows.Forms.PictureBox pictureBox69;
        private System.Windows.Forms.PictureBox pictureBox70;
        private System.Windows.Forms.PictureBox pictureBox71;
        private System.Windows.Forms.PictureBox pictureBox72;
        private System.Windows.Forms.PictureBox pictureBox73;
        private System.Windows.Forms.PictureBox pictureBox74;
        private System.Windows.Forms.PictureBox pictureBox75;
        private System.Windows.Forms.PictureBox pictureBox76;
        private System.Windows.Forms.PictureBox pictureBox77;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox Player;
        private System.Windows.Forms.Timer Bsecond;
        private System.Windows.Forms.Timer Slow;
        private System.Windows.Forms.Timer Normal;
        private System.Windows.Forms.Timer Second;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer Trace;
        private System.Windows.Forms.Timer Randd;
        private System.Windows.Forms.Timer Fast;
        private System.Windows.Forms.Timer BackG;
        private System.Windows.Forms.Timer Nice;
        private System.Windows.Forms.Timer Boom;
        private System.Windows.Forms.Timer Remix;
        private System.Windows.Forms.Label label1;
        private Database1DataSet database1DataSet;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private Database1DataSetTableAdapters.TableTableAdapter tableTableAdapter;
        private Database1DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView tableDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox nameTextBox1;
        private System.Windows.Forms.TextBox timeTextBox1;
    }
}